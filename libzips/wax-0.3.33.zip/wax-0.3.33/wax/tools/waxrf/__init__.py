# __init__.py

from waxrf import XMLResource
import imgcoder
